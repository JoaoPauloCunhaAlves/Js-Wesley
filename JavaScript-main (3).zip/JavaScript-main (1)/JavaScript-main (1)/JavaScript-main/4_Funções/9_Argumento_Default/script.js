function potencia(base, exp = 2) {
    return Math.pow(base, exp);
}
console.log(potencia(3));
console.log(potencia(3, 400));
console.log(potencia(3, 5));