console.log(typeof (5+3));
console.log(typeof (12-7));
console.log(typeof (23*7));
console.log(typeof (30/5));
console.log(20%2);
console.log(21%2);




