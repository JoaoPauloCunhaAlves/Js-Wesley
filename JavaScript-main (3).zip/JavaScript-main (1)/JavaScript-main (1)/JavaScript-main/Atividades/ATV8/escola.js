let idade = Number(prompt('Qual sua idade: '));
if (idade >= 18){
    console.log('Pode dirigir');
} else {
    console.log('Não pode dirigir ainda')
}



let nota = Number(prompt('Digite sua nota da prova: '));
if (nota >= 7) {
    console.log('Aprovado');
} else if (nota >= 5) {
    console.log('Recuperação');
} else {
    console.log('Reprovado');
}