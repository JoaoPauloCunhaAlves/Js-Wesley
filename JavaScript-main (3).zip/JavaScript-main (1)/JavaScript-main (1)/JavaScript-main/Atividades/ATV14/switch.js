let dia = Number(prompt('Digite um número para saber o dia da semana: '))

switch (dia) {
    case 1:
        console.log('Domingo');
        break;

    case 2:
        console.log('Segunda');
        break;

    case 3:
        console.log('Terça');
        break;

    case 4:
        console.log('Quarta');
        break;

    case 5:
        console.log('Quinta');
        break;

    case 6:
        console.log('Sexta');
        break;

    case 7:
        console.log('Sabádo');
        break;
}

//(B)
let cor = String(prompt('Insira uma cor: '));

switch (cor) {
  case 'azul':
    console.log('Você escolheu a cor dos  céus');
    break;

  case 'vermelho':
    console.log('Você escolheu a cor do amor');
    break;

  case 'verde':
    console.log('Você escolheu a cor da selva');
    break;

  default:
    console.log('Escolha outra');
    break;
}
