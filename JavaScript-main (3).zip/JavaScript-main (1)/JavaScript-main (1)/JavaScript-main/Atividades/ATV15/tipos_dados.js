let nome = 'jao';
console.log(typeof(nome));

let x = 15;
console.log(typeof(x));

let cartao = true;
console.log(typeof(cartao));

let infinito = undefined;
console.log(typeof(infinito));

let nulo = null;
console.log(typeof(nulo));




