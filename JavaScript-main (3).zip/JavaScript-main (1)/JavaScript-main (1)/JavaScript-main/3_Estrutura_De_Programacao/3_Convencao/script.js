let nome3 = 'teste';
let $nome = 'teste2';
console.log(nome3);