let nome = "Jose";
for (let i = 0; i < 10; i++){
    if (i == 3) {
        nome = "Joao"
    }
    if (i == 5 && nome == "Joao") {
        console.log("O nome e Joao, pode parar!");
        break;
    }
}