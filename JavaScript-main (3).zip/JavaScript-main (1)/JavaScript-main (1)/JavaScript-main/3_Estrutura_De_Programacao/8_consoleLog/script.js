let idade = 26;
let nome = "Jao";
console.log(`O meu nome é ${nome}, e tenho ${idade} anos`)