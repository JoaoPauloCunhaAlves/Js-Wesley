let consoleTeste = () => {
    console.log('Olá Turmas')
};
consoleTeste();

let somaNumeros = (num1, num2) => {
    console.log(num1 + num2)
}
somaNumeros(5, 6);