console.log(document.getElementsByTagName('li'));
console.log(document.getElementsByClassName('itens-azuis'));
console.log(document.getElementsByClassName('itens-vermelhos'));
console.log(document.getElementsByClassName('itens'));