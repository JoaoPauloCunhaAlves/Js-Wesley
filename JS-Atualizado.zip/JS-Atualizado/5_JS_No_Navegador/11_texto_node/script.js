let pSemTexto = document.getElementById('sem-texto');
let texto = document.createTextNode('Insirir esse texto');
pSemTexto.appendChild(texto);