let elemento = document.querySelector('#titulo-principal');
console.log('largura: ' + elemento.offsetWidth);
console.log('altura: ' + elemento.offsetHeight);

console.log('largura: ' + elemento.clientWidth);
console.log('altura: ' + elemento.clientHeight);