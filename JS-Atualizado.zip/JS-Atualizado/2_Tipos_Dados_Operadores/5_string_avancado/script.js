console.log("Primeira linha \nSegunda linha");
console.log(`A multiplicação de 5 por é igual a ${5 *3}`);
console.log(" O " + " Meu " + " Nome " + " é " + " Kelvin ");











