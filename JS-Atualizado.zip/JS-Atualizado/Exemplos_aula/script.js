var titulo = document.getElementById("titulo");
var conteudo = titulo.textContent;
console.log(conteudo);