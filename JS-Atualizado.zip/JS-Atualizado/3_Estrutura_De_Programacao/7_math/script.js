let maior = Math.max(6, 12, 20, 50, 100);
console.log(maior);

let menor = Math.min(6, 12, 20, 50, 100);
console.log(menor);

let arredondar = Math.round(3.14151926)
console.log(arredondar)

let arredondarProximo = Math.ceil(5.75)
console.log(arredondarProximo)

let arredondarBaixo = Math.floor(6.340);
console.log(arredondarBaixo)