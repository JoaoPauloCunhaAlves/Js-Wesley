for (let vassoura = 0; vassoura < 100; vassoura++){
    console.log(`A soma das posicoes da vassoura é: ${vassoura}`);
}