//let if = 'teste';

//let function 

let functionTest = 'aaaaaa'
let function1 = 'bbbbbb'