let x = 10;
while (x > 10){
    console.log("O x é: " + x)
}