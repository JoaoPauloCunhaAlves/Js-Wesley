//(A)
for (let i = 2; i <= 20; i += 2) {
    console.log(i);
}


//(B)
var num = Number(prompt('Digite um número para ver a tabuada'))
for (let tabuada = 1; tabuada <= 10; tabuada += 1) {
    console.log(`${num} X ${tabuada} = ${num*tabuada}`)
}
