console.log("Mensagem com console log");
console.warn("Mensagem com console warn");
console.error("Mensagem com console error")