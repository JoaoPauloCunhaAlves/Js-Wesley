//(A)
do {
  var num = Number(prompt('Digite um número para descobrir seu dobro'));
  console.log(num * 2);
} while (num != 0);

//(B)
do {
  var nome = String(prompt('Digite seu nome: '));
  console.log(nome);
} while (nome !== 'sair' || 'Sair');
