//(A)
for (let i = 1; i <= 10; i += 1) {
    console.log(i);
    if (i == 5){
        break;
    }
}


//(B)
for (let x = 0; x <= 10; x += 1){
    if (x % 2 == 0) {
        console.log(x);
        continue
    }
}