let contador = 1;
while(contador <= 10){
    console.log(contador++);
}


let digitou = Number(prompt("Adivinhe a senha: "));
 while(digitou != 1234){
    digitou = Number(prompt("Você ERROU!! tente novamente: "));
    if (digitou == 1234) {
        console.log("Você acertou!!");
        break;
    }
 }