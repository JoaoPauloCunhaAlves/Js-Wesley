var x = 7;
var y = 5;

let soma = x + y;
console.log(soma);

let subtracao = x - y;
console.log(subtracao);

let multiplicacao = x * y;
console.log(multiplicacao);

let divisao = x / y;
console.log(divisao);

var z = '7';
console.log(x == z);

var cinco = true;
console.log(y === cinco);

if (x != y) {
  console.log('São diferentes');
}

if (x > 1 && y > 1) {
  console.log('São maiores que 1');
}

if (x > 1 || y > 1) {
  console.log('Um deles e maior que 1');
}
